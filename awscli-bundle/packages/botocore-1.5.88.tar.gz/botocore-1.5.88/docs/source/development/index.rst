Botocore Development
********************

.. toctree::
   :maxdepth: 2

   changesfor10
   designnotes
